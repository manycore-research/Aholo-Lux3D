# Execution and recovery

Choose the interface needed for the current action. Read the command's `--help` for arguments and the contracts below for request, response, and state structures.

## Use capabilities as needed

### Before calling a Lux3D API

Let the user choose the region; do not infer it automatically. Ask if no region has been selected, or reuse an explicit choice. Before the call, load the saved configuration for that region into the tool process. The tool reads the API key and authenticates through the actual request. If credentials are missing or invalid, follow the setup flow below. Conversation and local operations do not require an authentication check. A network or service failure does not mean the key is invalid.

### Set up an API key

Follow [Common credential setup](credentials.md). Keep keys in the host's secure credential provider or an isolated child process environment. Never request keys in chat. The same package resolves attribution from the active host session; no profile selection or installation binding file is needed.

### Query or refresh the account

Use `balance` in `scripts/commerce.py` to query balance, trial access, and membership entitlements, or to verify setup and account changes after a top-up. See `core/contracts/lux3d-commerce.v1.json` for responses and errors. Quoting already refreshes the account, so a separate balance query is not needed before every API call.

If balance or required entitlements are insufficient, help the user address the issue and query again before resuming. Do not require an upgrade for optional concurrency. After switching accounts, refresh quotes using [Understanding and planning](planning.md).

Use the returned `accountRef`, `region`, `source`, `uniqueId`, and `uniqueIdExpiresAt` to associate account facts with a quote. If a balance refresh changes `uniqueId` or the account, the earlier quote no longer applies: quote the intended work again. Do not invent membership requirements from `memberType` or trial names; enforce only requirements documented for the selected capability or returned by the service.


## Account task concurrency

The account's shared generation task limit is **5 for free users** and **20 for
paid users**. Use the current successful account response: boolean `member=true`
selects the paid/pro limit; `member=false` selects the free limit. Do not infer
paid status from a positive credit balance, a top-up, trial access or the host.
If membership is unknown, refresh the account before using the paid limit and
use at most the free limit while the other account/quote requirements remain met.

These limits count unfinished asynchronous tasks, not simultaneous HTTP requests
or calls per second. States 0, 1 and 2 occupy slots. Count the account's existing
active tasks across operations, API keys, hosts and Skill/MCP sessions; changing
source, quoteId or connection does not create a fresh quota. All nine generation
operations, including retopology, articulation, auto-rig and animation retargeting,
share this pool. One retarget create with several action IDs occupies one slot.
Multi-format export remains outside this shared generation pool; do not invent
an export quota from the generation limit.

Use one account coordinator to reserve available slots before dispatching ready,
authorized and quoted steps. Available slots are the limit minus observed active
tasks and local reservations not already represented by those tasks. Dependencies
must be ready before submission. Release a reservation on an explicit rejection
that created no task, or after observing a terminal provider state. Creation HTTP
completion, query timeout, local download failure and an uncertain submission do
not release a task slot. Reconcile uncertainty before creating again. If task-list
coverage or durable coordination is unavailable, serialize work conservatively
instead of assuming all slots are free. Limits are ceilings, not a target count.

**Part splitting has a separate per-account limit of 5 for every user**, including
paid users. Do not apply the paid generation limit of 20 to part splitting. This
policy does not add a part-split tool: the current plugin has no part-split route;
only invoke such an operation after its actual interface has been integrated and
discovered. The server may also enforce global capacity or account-specific limits.

On `GENERATION_CONCURRENCY_LIMIT_EXCEEDED`, pause new creates, keep/query existing
task IDs and wait for capacity. Never retry an uncertain create, switch accounts
or endpoints to evade the cap, or regenerate to recover a delivery failure. A
successful account/quote does not reserve server slots or authorize new spending.
The host coordinates this workflow through instructions; the server remains the
authority across processes and devices. No new server-side semaphore is installed.

### Recover from timestamp precision errors

Account and quote timestamps may have nanosecond precision, for example `2026-09-30T14:43:00.832650958+08:00`. Use the bundled `workflow_contracts.parse_datetime` helper: it parses a copy as `2026-09-30T14:43:00.832650+08:00`, preserves the offset and converts the result to UTC. It accepts 1-9 fractional digits, padding shorter fractions to six digits and truncating longer ones without rounding. Keep the server's original response unchanged.

If an older parser rejects this timestamp shape, apply the same precision-only conversion to the local parsing copy and rerun normal validation, then continue with the same account/quote response. This needs no key reset, region switch or repeated quote request. Continue checking required fields, context and quote expiry; never replace the server time with the current time, remove the timezone, extend an expiry or treat a parsing failure as free pricing. Only if conversion still fails, report the failed field and format without raw credentials or account contents, and pause the affected API-dependent step.

A timestamp parsing error or `RESPONSE_INVALID` does not establish invalid credentials. Use `API_KEY_REQUIRED` for missing configuration and `UNAUTHORIZED` for rejected authentication; treat network restrictions separately. A successful balance check or quote still does not authorize paid generation.

### Submit or resume a generation step

Use the bundled Python API in `core/runtime/lux3d_client.py`. With the configured Python interpreter, add the installed Skill's `core/runtime` directory to the process's import path and import `lux3d_client`. Pass the selected `region` and the approved parameters explicitly. Read the selected function's signature and `core/contracts/lux3d-generation.v1.json` for arguments and output formats.

| Operation | Submission function |
| --- | --- |
| Text to 3D | `create_text_to_3d_task` |
| Image(s) to 3D | `create_image_to_3d_task` |
| Material transfer | `create_material_transfer_task` |
| Four-view generation | `create_image_to_four_view_task` |
| Format conversion | `create_multi_format_export_task` |
| Character auto-rigging | `create_auto_rig_task` |
| Character animation retargeting | `create_animation_retarget_task` |

For digital-human inputs, actions and structured results, follow [Digital humans](digital-human.md). These operations do not use a generation `version`; retargeting returns one action result per requested animation instead of one URL per format.

Generation correlation is an explicit per-call argument, not process-global state. Example: `create_text_to_3d_task(prompt, version=version, region=region, content_id=current_quote["quoteId"])`. If using a `generate_*` convenience wrapper, pass the same `content_id`; existing create CLI commands use `--content-id <quoteId>`. Do not add it to query/list or quote input parameters. This metadata does not authorize spending.

These functions submit one task and return its ID. Use them separately from polling so the ID can be saved immediately. They do not check user approval or manage the plan's budget. The agent performs the following steps:

1. Check that the current step still satisfies the agreed constraints in the plan, and that its inputs and dependencies are ready. Inspect generated four-view inputs using the check below before submitting them to 3D generation. Match the actual operation, model, parameters, quantity, account, and region to a successful, unexpired quote from `scripts/commerce.py quote`. Requote changed or expired work and apply [Review and approval](review.md), including the remaining cumulative conversation allowance and any new retry costs. Check the account facts and required entitlements; refresh stale facts before submission.
2. Use the attempt record and recovery rules below to establish that this step has not already been submitted. Keep one submitting process per attempt.
3. Before making the call, save a local attempt record with the region, a non-secret account reference, the operation and approved parameter snapshot, quote/approval references, retry count, and submission start time. If a conversation budget is active, reserve the quoted allowance through the task's single budget coordinator and associate it with this attempt. Reuse an existing batch reservation rather than count the same amount again. Immediately before dispatch, mark submission as started and move the reservation to committed allowance. Keep temporary input URLs in private working files; do not copy credentials or signed URLs into portable records.
4. Call the selected `create_*_task` function once, passing `content_id=current_quote["quoteId"]` from the successful, unexpired quote matched to this step. The wire field is `contentId`. For articulation, omit this argument and keep quoteId in the local attempt record because its public body accepts only glbUrl and prompt. For other newly quoted plugin work, do not omit it, substitute `uniqueId`/`pluginTaskId`, or invent an ID. Immediately save its returned ID to the attempt record and budget ledger before polling or doing other work. If the call times out, its result cannot be parsed, or saving the ID fails, preserve all available evidence and treat the outcome as uncertain. Keep its allowance committed; do not rerun the create call or assume a refund to recover it.
5. Query the saved ID until it reaches a terminal state, updating the record with actual status and timestamps. Download and inspect successful outputs, then follow [Results and delivery](results.md). A tracking interruption resumes from the saved ID.

This is agent orchestration using existing client functions, not a runtime-enforced approval, budget, or idempotency guarantee. Do not route this path through `workflow_runner.py run` or `resume`: its default CLI does not supply the required execution adapters. Their absence does not make the client functions unavailable. An actual authentication, entitlement, permission, or service rejection must still be handled; do not change accounts or endpoints to evade it.

The full `lux3d-workflow/v2` execution contract describes the runner's verification, gate and registry ports. Direct client orchestration does not implement those ports. Do not fabricate their decisions or describe a local delivery snapshot as compliance with that execution contract.

### Keep records and resume at the unfinished stage

Keep one task-local record per generation attempt and update it as facts arrive, rather than reconstructing submission history from separate scripts. It holds the stable item/attempt IDs, account/region, operation and parameter snapshot, quote/approval references, retry count, submission state, returned task ID, provider status, timestamps, and downloaded file paths. Keep private request inputs separate from portable delivery data. Budget amounts and reservation rules belong to the ledger in [Review and approval](review.md); refer to its entries rather than maintain another total.

On interruption or context compression, retain the record locations, current stage, unfinished items, and next action, plus the budget ledger location and totals if active. Resume according to the recorded facts:

| Known state | Next action |
| --- | --- |
| No submission started | Check current inputs, quote, and approval before submitting. |
| Submission started, outcome uncertain | Reconcile the original call; if unresolved, pause that step without another create call. |
| Task ID saved | Query that ID with its recorded account and region. |
| Generation succeeded, files missing | Download and inspect the original outputs. |
| Models ready, Blender work unfinished | Resume from the saved scene/script and completed renders using [Scene assembly and rendering](assembly.md). |
| Outputs ready, packaging or preview failed | Repair delivery using [Results and delivery](results.md). |

Keep generation, download, Blender, and packaging progress distinct. A later-stage failure does not erase an earlier success. Derive the delivery snapshot from these records as described in results; it is not a second execution log or authorization record.

### Query tasks or find records

Use `query` in `core/runtime/lux3d_client.py` to check the original task, or `list` to find generation records. The corresponding Python functions are `get_task` and `list_tasks`. Read `--help` or the function signature for arguments and `core/contracts/lux3d-generation.v1.json` for statuses and errors. Use query results to establish the actual state; a similar description alone does not identify the same task. Query with the recorded account and region. Resume from that record, without submitting again. If an uncertain submission cannot be conclusively matched to a task, pause that step.

### Read and download successful outputs

Use the existing output helpers in `lux3d_client.py`; do not guess formats from URL suffixes or drop empty result slots before interpreting them.

- Text/image to 3D: determine `expectedFormats` with `generation_result_formats(version, outputFormat)` and parse a successful task with `parse_task_outputs`.
- Material transfer: use `material_result_formats(outputFormat)` and `parse_fixed_output_slots(task_data, MATERIAL_OUTPUT_SLOTS)`.
- Format conversion: use `export_result_formats(modelUrl, outputFormat)` and `parse_fixed_output_slots(task_data, EXPORT_OUTPUT_SLOTS)`.
- Four-view generation: use `parse_task_outputs` and require the documented four URLs. When used for 3D generation, retain their documented order and inspect consistency before proceeding. If the user requested the images themselves, download and deliver them directly as described in results.

For model outputs, `download_requested_models(outputs, output_path, expected_formats)` downloads the requested formats. Its return value is a list of `(path, byte_count)` pairs, not workflow state. Build delivery records from those real files. A saved task may also be polled/downloaded with `complete_task`, supplying the matching `expected_formats` and, for material/export, `output_slots`. Never use a `generate_*` convenience function to resume; it creates a new task before polling.

### Change or cancel running work

Query the original task first, then use only the modification or cancellation interfaces actually exposed. Update unsubmitted work through [Understanding and planning](planning.md). If the user asks to stop, stop further submissions and accurately report any work still running. A cancellation request does not establish successful cancellation or a refund.

The bundled client currently exposes no cancellation or in-place task modification command. Do not invent one. Without another verified interface, stop unsubmitted work and explain that an already submitted task may continue.

## Inspect visual inputs and correct mismatches

Before using generated four-view images, inspect them together with the original reference. Check that they describe the same object with consistent structure and asymmetric landmarks such as openings, stairs, or a porch. Distinguish an expected change of viewpoint from genuinely mirrored or contradictory geometry. A successful image-generation task alone does not establish input consistency. Preserve the documented view order; arbitrary reordering is not a repair for conflicting views.

If a view is inconsistent, use a supported operation to regenerate the affected view, or regenerate the set if individual correction is unavailable. Inspect the replacement before use. If consistency still cannot be established, consider single-image generation from the original asset reference, provided the user's requirements permit it; explain a material route change. Do not repeatedly generate 3D from known conflicting inputs or mirror the finished model merely to disguise a mismatch.

Inspect successful 3D outputs against the agreed structure, orientation, silhouette, and material requirements before relying on them for assembly or declaring completion. For a concrete visual mismatch, identify whether the input, generation route, or local assembly needs correction. A justified new generation is production revision, not recovery from a download or preview failure. Quote its cost and apply the existing approval mode and remaining budget before submission. For either inconsistent four-view images or a mismatched 3D model, make at most one automatic corrective regeneration for the same mismatch by default. If it persists, revise the approach or report the limitation rather than loop; renaming the mismatch or changing attempt IDs does not reset this limit. A user explicitly requesting further candidates may authorize a larger bounded search. Preserve previous usable outputs and stop when the requirement is met or the authorized allowance is insufficient.

## Execution rules

- Before every new billable submission, including a retry, apply [Review and approval](review.md). Automatic execution uses the cumulative conversation budget. Each new retry has its own allowance entry; query retries keep the original task and do not consume additional generation allowance. Do not reset usage when the plan, attempt ID or context changes.
- Keep querying the original ID for an existing task. Successful submission does not mean generation is complete. If a query fails or the tracking window ends, preserve the last known state. Do not regenerate, report generation failure, or promise background tracking that is not available.
- Verify an uncertain submission result before proceeding. If it cannot be verified, pause that attempt and its dependent work instead of resubmitting. Independent work may continue only when its inputs, authorization, and budget remain established, with the uncertain amount still committed.
- After a confirmed generation failure, automatically resubmit the original step at most once, only if the failure is suitable for retry and the cost has the required approval. A new task ID does not reset this limit. Stop after another failure.
- If generation succeeds but downloading, opening files for inspection, or previewing fails, recover that local stage using [Results and delivery](results.md), without regenerating. A successfully inspected model that visibly misses agreed requirements follows the visual-correction rules above; a user-requested appearance change follows [Understanding and planning](planning.md).


## Local model-articulation execution

Use workflow operation `articulation-animation` with `glbUrl`, `prompt`, `region`,
`target` and the existing submission context. The workflow preserves quoteId locally
and applies the existing quote verifier, submission gate and registry; the actual
POST body contains only `glbUrl` and `prompt`.

The client exposes `create_articulation_animation_task(glbUrl, prompt, region=...)`,
`generate_articulation_animation` and `resume_articulation_animation`. It accepts no
`content_id`. Prefer create → immediately record task ID → resume when managing the
execution ledger directly. CLI equivalents:

```text
python core/runtime/lux3d_client.py --region cn articulation GLB_URL --prompt "Keep the base fixed and slowly open the lid" --submit-only
python core/runtime/lux3d_client.py --region cn articulation-result TASK_ID output-basename
```

Only submit after the matched quote and current-dialogue approval. Queries use the
regional shared task endpoint; status 3 must contain exactly one HTTP(S) result URL.
Query/download failures resume the same task and never create a replacement automatically.
Unknown submission outcomes require reconciliation with task history. Do not add a
Connector tool name until it is available through live MCP discovery.

## Local mesh-retopology execution

Use workflow operation `mesh-retopology` with modelUrl, faceLimit, quad, bakeTextures and
textureSize. Reuse the existing trusted generation port, quote verifier, current-conversation
submission gate and registry. Do not place version in this workflow. contentId comes from
the current valid quoteId, not uniqueId/pluginTaskId, and is not idempotency protection.

The shared client also exposes create_mesh_retopology_task and generate_mesh_retopology;
pass content_id=current_quote["quoteId"] at actual creation. The CLI is
`retopology <GLB_URL> [output-basename] --face-limit N [--triangle] [--bake-textures] [--texture-size 2048] [--content-id QUOTE_ID]`.
This is a low-level capability, not a new authorization bypass: preserve the existing confirmed
plan/price checks before invoking it. No new live paid submission is authorized by this guide.

Persist the returned task ID immediately; CLI emits it before polling. Use workflow resume
or `retopology-result TASK_ID [output-basename] [--bake-textures]` after an interruption.
Creation outcome unknown requires reconciliation, never blind POST retry.
Query/download/report retries do not recreate the paid generation task.
Remote mode requires an observed real tool/schema; do not invent tool names or switch modes silently.
